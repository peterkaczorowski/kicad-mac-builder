This directory provides a set of demo scripts for using OCCT functionality from
within DRAW Test Harness. Call the scripts from DRAW prompt, e.g.:

Draw[]> source samples/tcl/VisualizationDemo.tcl
